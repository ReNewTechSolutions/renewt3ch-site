## Fonts

**Official Renewt3ch Typeface System**

Renewt3ch uses a modern, tech-forward system built around **Poppins**, **Inter**, and **Space Grotesk**.  
These three cover branding, UI, body copy, dashboards, and headings.

---

## Primary Brand Font — Poppins

**Use for:** headings, hero text, large statements, branded visuals  
**Style:** tech-modern, geometric, bold  
**Weights included:** 300 / 400 / 500 / 600 / 700 (+ variable)

**CSS import (recommended: variable WOFF2)**
```css
@font-face {
  font-family: "Poppins";
  src: url("/assets/fonts/poppins/Poppins-Variable.woff2") format("woff2-variations");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
/* Optional static weights (TTF fallback) */
@font-face { font-family: "Poppins"; src: url("/assets/fonts/poppins/static/Poppins-Light.ttf") format("truetype"); font-weight: 300; font-style: normal; font-display: swap; }
@font-face { font-family: "Poppins"; src: url("/assets/fonts/poppins/static/Poppins-Regular.ttf") format("truetype"); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: "Poppins"; src: url("/assets/fonts/poppins/static/Poppins-Medium.ttf") format("truetype"); font-weight: 500; font-style: normal; font-display: swap; }
@font-face { font-family: "Poppins"; src: url("/assets/fonts/poppins/static/Poppins-SemiBold.ttf") format("truetype"); font-weight: 600; font-style: normal; font-display: swap; }
@font-face { font-family: "Poppins"; src: url("/assets/fonts/poppins/static/Poppins-Bold.ttf") format("truetype"); font-weight: 700; font-style: normal; font-display: swap; }
```
---

### Section 3 — Inter (Secondary UI Font)
```md
## Secondary UI Font — Inter

**Use for:** UI elements, dashboards, buttons, forms, charts  
**Style:** highly legible, optimized for screens  
**Weights included:** 300 / 400 / 500 / 600 / 700 (+ variable)

```css
@font-face {
  font-family: "Inter";
  src: url("/assets/fonts/inter/Inter-Variable.woff2") format("woff2-variations");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
/* Optional static weights (TTF fallback) */
@font-face { font-family: "Inter"; src: url("/assets/fonts/inter/static/Inter-Light.ttf") format("truetype"); font-weight: 300; font-style: normal; font-display: swap; }
@font-face { font-family: "Inter"; src: url("/assets/fonts/inter/static/Inter-Regular.ttf") format("truetype"); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: "Inter"; src: url("/assets/fonts/inter/static/Inter-Medium.ttf") format("truetype"); font-weight: 500; font-style: normal; font-display: swap; }
@font-face { font-family: "Inter"; src: url("/assets/fonts/inter/static/Inter-SemiBold.ttf") format("truetype"); font-weight: 600; font-style: normal; font-display: swap; }
@font-face { font-family: "Inter"; src: url("/assets/fonts/inter/static/Inter-Bold.ttf") format("truetype"); font-weight: 700; font-style: normal; font-display: swap; }
```

---

### Section 4 — Space Grotesk (Accent / Display Font)
```md
## Accent / Display Font — Space Grotesk

**Use for:** sub-headings, large UI labels, numbers, futuristic branding moments  
**Style:** clean, rounded, slightly sci-fi  
**Weights included:** 300 / 400 / 500 / 600 / 700 (+ variable)

```css
@font-face {
  font-family: "Space Grotesk";
  src: url("/assets/fonts/space-grotesk/SpaceGrotesk-Variable.woff2") format("woff2-variations");
  font-weight: 300 700;
  font-style: normal;
  font-display: swap;
}
/* Optional static weights (TTF fallback) */
@font-face { font-family: "Space Grotesk"; src: url("/assets/fonts/space-grotesk/static/SpaceGrotesk-Light.ttf") format("truetype"); font-weight: 300; font-style: normal; font-display: swap; }
@font-face { font-family: "Space Grotesk"; src: url("/assets/fonts/space-grotesk/static/SpaceGrotesk-Regular.ttf") format("truetype"); font-weight: 400; font-style: normal; font-display: swap; }
@font-face { font-family: "Space Grotesk"; src: url("/assets/fonts/space-grotesk/static/SpaceGrotesk-Medium.ttf") format("truetype"); font-weight: 500; font-style: normal; font-display: swap; }
@font-face { font-family: "Space Grotesk"; src: url("/assets/fonts/space-grotesk/static/SpaceGrotesk-SemiBold.ttf") format("truetype"); font-weight: 600; font-style: normal; font-display: swap; }
@font-face { font-family: "Space Grotesk"; src: url("/assets/fonts/space-grotesk/static/SpaceGrotesk-Bold.ttf") format("truetype"); font-weight: 700; font-style: normal; font-display: swap; }
```

---

### Section 5 — Typography Rules (table)
```md
## Typography Rules

| Usage                 | Recommended Font | Weight   | Size     |
|-----------------------|------------------|----------|----------|
| Hero / Large Headline | Poppins          | 600–700  | 48–72px  |
| Section Headings      | Poppins          | 500–600  | 32–48px  |
| Subheadings           | Space Grotesk    | 500      | 22–28px  |
| UI Labels / Buttons   | Inter            | 500–600  | 14–18px  |
| Body Text             | Inter            | 400      | 16–18px  |
| Captions / Notes      | Inter            | 300–400  | 12–14px  |
```

---

## Font Pairing Examples

**Great combos**
- Poppins **Bold** + Inter **Regular** → strong hero + clean body  
- Poppins **SemiBold** + Inter **Medium** → dashboards & app UI  
- Space Grotesk **Medium** → numeric UI / metrics  
- Inter **SemiBold** → primary buttons & form labels

**Avoid**
- Mixing more than **two** families per page  
- Using Space Grotesk for long paragraphs

---

## File Structure

```text
assets/
└─ fonts/
   ├─ inter/
   │  ├─ static/*.ttf
   │  └─ Inter-Variable.woff2
   ├─ poppins/
   │  ├─ static/*.ttf
   │  └─ Poppins-Variable.woff2
   └─ space-grotesk/
      ├─ static/*.ttf
      └─ SpaceGrotesk-Variable.woff2
```

---

### Section 8 — Licensing
```md
## Licensing

All fonts are licensed under the **SIL Open Font License (OFL 1.1)** — free for personal and commercial use.

---

## Support & Contact

Replace with your org’s details before handoff.

**Brand Support Contact (Replace)**
- **Email:** yourname@yourcompany.com  
- **Website:** https://yourcompany.com  
- **Design Owner:** Your Company / Brand Team