# Renewt3ch Logo System  
Modern • Minimal • Futuristic Iconography

This folder contains the complete Renewt3ch logo suite, including icons, full lockups, gradient marks, and monochrome variants. Each asset is optimized for digital interfaces, dashboards, and branding use cases.

---

## Logo Variants

### **Primary Logo (Full Lockup)**
- `Logo-Renewt3ch.svg`  
  The official brand lockup featuring the **R³ icon** + **Renewt3ch wordmark**.

---

### **R³ Icon**
For UI, favicons, app icons, badges, and avatar use.

- `r3-icon-black.svg`  
- `r3-icon-white.svg`  
- `r3-icon-gradient.svg`  

Use gradient for hero sections and promo materials.  
Use black/white icon for clean UI and dashboard elements.

---

### **Wordmark**
For headings, site headers, footers, hero sections, and print.

- `wordmark-black.svg`  
- `wordmark-pure-white.svg`  

Wordmark is designed for high legibility and geometric balance.

---

## Logo Usage Rules

### ✔ Use Appropriately
- Maintain **minimum padding = 1× height of the “r” icon** around all sides.
- Use black/white versions for UI, light/dark themes.
- Use gradient only for premium / hero design moments.
- Keep SVGs uncompressed to preserve vector quality.

### ❌ Avoid
- Stretching or distorting the logo  
- Adding shadows, embossing, filters, or outlines  
- Rotating or skewing the mark  
- Recoloring outside the official palette  
- Placing on low-contrast backgrounds  

---

## 💡 Recommended File Types

| Use Case | File Type | Asset |
|----------|-----------|-------|
| Website UI | `.svg` | All icons/wordmarks |
| Web Hero Sections | `.svg` | Gradient versions |
| Print | `.svg` or high-res `.png` | Wordmark or full lockup |
| Social / App Icons | `.png` (512×512) | R³ icon |

---

## 📁 Folder Structure
logos/
   Logo-Renewt3ch.svg
   r3-icon-black.svg
   r3-icon-white.svg
   r3-icon-gradient.svg
   wordmark-black.svg
   wordmark-pure-white.svg
   README.md

---

## Testing Tips
- Test icons on **white, black, and transparent** backgrounds.
- Verify scaling at **32px, 64px, 128px, and 512px**.
- Confirm gradient version renders correctly in Safari + mobile.

---

## 🟢 License
All logo assets are © Renewt3ch®.  
Ownership transfers to the buyer upon sale.

---

## Branding Support
If reselling this brand kit, remember to replace contact details with the new owner’s information.

This completes the logo documentation for the Renewt3ch Brand Kit.