# Renewt3ch Favicon Package

This folder contains all favicon assets needed for full browser and device compatibility.

---

## Included Files

| File | Purpose |
|------|---------|
| `favicon.svg` | Vector tab icon (preferred in modern browsers) |
| `favicon.ico` | Legacy/Windows browsers |
| `favicon-96x96.png` | High-res desktop fallback |
| `favicon-192x192.png` | Android/PWA icon |
| `favicon-512x512.png` | Android/PWA large icon |
| `apple-touch-icon.png` | iOS home-screen icon |
| `site.webmanifest` | PWA metadata |

> If your project doesn’t use SVG favicons, you can omit `favicon.svg`.

---

## How to Use

### HTML `<head>` snippet (project root paths)

```html
<link rel="icon" type="image/svg+xml" href="/assets/favicon/favicon.svg">
<link rel="alternate icon" type="image/x-icon" href="/assets/favicon/favicon.ico">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="192x192" href="/assets/favicon/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/favicon/apple-touch-icon.png">
<link rel="manifest" href="/assets/favicon/site.webmanifest">
<meta name="theme-color" content="#0D0D0D">
```
---

### Section 4 — PWA Manifest (reference)

```markdown
## PWA Manifest (reference)

Your `site.webmanifest` should include the icons listed above, for example:

```json
{
  "name": "Renewt3ch",
  "short_name": "Renewt3ch",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0D0D0D",
  "theme_color": "#0D0D0D",
  "icons": [
    { "src": "/assets/favicon/favicon-192x192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/assets/favicon/favicon-512x512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

---

### Section 5 — Notes & Tips

```markdown
## Notes & Tips

- All icons use the **R³ mark**, tuned for clarity at small sizes.  
- PNGs are optimized for **Retina/4K** displays.  
- After replacing icons, **hard-refresh** or clear browser cache to see updates.  
- Keep favicons **transparent** unless your design requires a solid background.

---

## Files Included

```text
assets/
└─ favicon/
   ├─ favicon.svg
   ├─ favicon.ico
   ├─ favicon-96x96.png
   ├─ favicon-192x192.png
   ├─ favicon-512x512.png
   ├─ apple-touch-icon.png
   ├─ site.webmanifest
   └─ README.md
```