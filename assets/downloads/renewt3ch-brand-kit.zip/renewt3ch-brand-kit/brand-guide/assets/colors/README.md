# Renewt3ch Color System

The Renewt3ch palette combines deep neutrals with crisp blue/aqua accents for high-contrast, UI-friendly design.

---

## Core Palette

| Name            | Hex      | Usage                                      |
|-----------------|----------|--------------------------------------------|
| **Infinite Blue** | `#0C85FF` | Primary actions, links, key highlights     |
| **Aqua Mint**     | `#2FF3E0` | Secondary accent, gradients, hover states |
| **Void Black**    | `#111111` | Page backgrounds                          |
| **Graphite Gray** | `#151515` | Cards, panels, elevated surfaces          |
| **Deep Slate**    | `#222222` | Dividers, subdued surfaces                |
| **Pure White**    | `#FFFFFF` | Text on dark, icons, keylines             |

---

## Palette File

This folder includes:

- `palette.png` — visual palette bar  
- HEX values  
- Contrast recommendations

Use the palette PNG for:
- Web previews  
- Pitch decks  
- UI guidelines  
- Design handoffs

---

## Usage Rules

- Avoid large fields of bright blue/aqua—use as accents or controlled gradients.  
- Keep dark backgrounds in the **#111111–#151515** range.  
- Use **Deep Slate** for dividers and subtle UI structure.  
- Reserve **Pure White** for text and keylines on dark.

---

## Accessibility

Minimum contrast ratios:
- Body text: **4.5:1**
- Large text (≥18pt / 14pt bold): **3:1**

**Infinite Blue** / **Aqua Mint** on **Void Black** pass WCAG AA when used for buttons and links with sufficient size/weight.

---

## Files Included
```text
brand-guide/
└─ assets/
   └─ colors/
      ├─ palette.png   # Color palette image
      └─ README.md     # This file
```