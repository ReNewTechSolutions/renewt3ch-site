# Renewt3ch Brand Guide (HTML Overview)

This folder contains the **HTML brand guide**—the visual counterpart to the main README.

---

## What’s Included

### `brand-guide.html`
Polished, dark-themed guide with:
- Logo previews
- Color palette blocks
- Typography samples
- Spacing & logo rules
- Font import snippets
- UI usage examples

### `brand-guide.md`
This file — GitHub-friendly summary and usage notes.

---

## Purpose

Made for:
- Client handoff
- Internal teams
- Developers integrating the brand
- Buyers (Flippa listing assets)
- Static hosting (Vercel, GitHub Pages, Netlify)

Lightweight and portable by design.

---

## How to View

Open in any browser:
- Double-click `brand-guide.html`, or
- Drag it into Chrome / Firefox / Safari.

> Uses relative assets from `../assets/...` (logos, colors, previews). If you move folders, update the paths in `brand-guide.html`.

---

## Optional: Convert to PDF

- Chrome → **Print** → **Save as PDF**
- VS Code “HTML to PDF”
- Any HTML-to-PDF tool

> Tip: Printing margins are already set in the page CSS for clean output.

---

## Folder Contents

```text
brand-guide/
├─ brand-guide.html
└─ brand-guide.md
```

## Dev Notes

- Brand tokens & fonts live in `brand-guide/assets/brand.css` (or `../assets/brand.css` if you centralize).
- Include via:

```html
<link rel="stylesheet" href="assets/brand.css">
```

## Asset Paths

- Logos: `../assets/logos/`
- Palette image: `../assets/colors/palette.png`
- Font previews: `../assets/previews/`

---

## Accessibility

- Provide meaningful alt text: `alt="Renewt3ch logo"` / `alt="Renewt3ch wordmark"`.
- Keep clearspace around the logo = **1× height of the “r”**.
- Minimum sizes: full lockup ≥ **200px** width; icon ≥ **32×32px** in UI.
- Ensure color contrast meets WCAG AA (the guide’s defaults do).

---

## License & Transfer

- See `license.txt` for fonts and custom graphics terms.
- If reselling/transferring, include a brief transfer note and any buyer instructions in `/instructions`.

---

## ✔ Tips for Resale

- Replace support/contact details before handoff.
- Keep printable guides in `/instructions` (buyers can “Print to PDF”).
- Keep paths consistent so the HTML renders out of the box.

---

## Version

- **v1.0.0** — Initial release of the HTML guide and assets.