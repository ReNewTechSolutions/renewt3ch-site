<!-- File: instructions/README.md -->
# Instructions (Printable Guides)

This folder contains printable HTML guides for buyers.

## How to export PDFs (no tooling required)

1. Open a guide in your browser:
   - [how-to-add-your-logo.html](./how-to-add-your-logo.html)
   - [how-to-edit-site.html](./how-to-edit-site.html)
   - [how-to-transfer-domain.html](./how-to-transfer-domain.html)
2. Print to PDF:
   - **Chrome/Edge:** **File → Print…** (or **Cmd/Ctrl+P**) → **Save as PDF** → enable **Background graphics**.
   - **Safari/Firefox:** **File → Print…** → **Save as PDF** (colors are preserved by default).
3. Save into this same folder using the same base name:
   - `how-to-add-your-logo.pdf`
   - `how-to-edit-site.pdf`
   - `how-to-transfer-domain.pdf`

> The guides include print styles and margins; output is A4-friendly. For US Letter, change the paper size in the print dialog.

## Quick launcher

- Open [index.html](./index.html) for one-click access to all guides.

## Optional

Prefer automation later? You can add a Puppeteer script to export PDFs. For this kit we intentionally keep it simple.