# Renewt3ch® Brand Kit
*Modern · Futuristic · Minimal · High-Tech identity system*

Welcome to the official **Renewt3ch Brand Kit**—a complete identity system for modern technology brands.  
Structured for **professional resale**, it includes pre-built documentation, scalable logo systems, color assets, font systems, favicons, previews, and a full HTML brand guide.

## Contents
- [Brand Overview](#brand-overview)
- [Included Assets](#included-assets)
- [Typography System (Quick Overview)](#typography-system-quick-overview)
- [Logo System (Quick Overview)](#logo-system-quick-overview)
- [File Structure](#file-structure)
- [Licensing](#licensing)
- [How to Use This Kit](#how-to-use-this-kit)
- [CSS Variables (Drop-in)](#css-variables-drop-in)

---

## Brand Overview

**Renewt3ch** blends:
- Minimal geometric forms
- Clean black-on-neon contrast
- Futuristic, UI-influenced design
- Precise grid alignment
- A scale-safe icon + wordmark system

**Ideal for**
- AI tools & automations
- SaaS / startups
- Developer platforms
- Dashboards & web apps
- Personal tech brands
- FinTech / data products

---

## Included Assets

| Section          | Contents                                                            |
|------------------|---------------------------------------------------------------------|
| **colors**       | Palette PNG, HEX codes, usage notes                                 |
| **logos**        | Icons, gradients, monochrome variants, full lockups                 |
| **fonts**        | Poppins, Inter, Space Grotesk + variable fonts + import snippets    |
| **favicon**      | ICO + PNG sizes + `site.webmanifest` / browser icons                |
| **previews**     | Font weight previews, palette preview, logo grid & mockups          |
| **brand-guide**  | Full HTML brand guide + Markdown version                            |
| **instructions** | Edit, upload, and transfer documentation for new owners             |

Designed so buyers can **plug it into a new or existing project** or re-sell it as part of a brand/website package.

---

## Typography System (Quick Overview)

| Usage               | Font          | Weight   | Size     |
|---------------------|---------------|----------|----------|
| Hero headline       | Poppins       | 600–700  | 48–72px  |
| Section heading     | Poppins       | 500–600  | 32–48px  |
| Subheadings         | Space Grotesk | 500      | 22–28px  |
| UI labels / buttons | Inter         | 500–600  | 14–18px  |
| Body text           | Inter         | 400      | 16–18px  |
| Captions            | Inter         | 300–400  | 12–14px  |

Full details: `/assets/fonts/README.md`.

---

## Logo System (Quick Overview)

**Primary assets**
- `logo-renewt3ch.svg` — full lockup
- `r3-icon-*.svg` — R³ icon in black, white, and gradient variants
- Wordmarks in light/dark and horizontal/stacked layouts

**Usage rules (summary)**
- Maintain clearspace = **1× the height of the “r”** around the logo
- Use monochrome logos for app UI and light/dark themes
- Reserve gradients for hero sections, landing pages, and high-impact placements
- Do not stretch, recolor, add filters/shadows, or rotate the logo

Full documentation: `/assets/logos/README.md`.

---

## File Structure

```text
RENEWT3CH-BRAND-KIT/
│
├── brand-guide/
│   ├── assets/               # Local CSS/JS for HTML guide
│   ├── brand-guide.html      # Full visual brand guide
│   ├── brand-guide.md        # Markdown version
│   └── README.md
│
├── assets/
│   ├── colors/
│   ├── favicon/
│   ├── fonts/
│   ├── logos/
│   ├── previews/
│   └── README.md
│
├── instructions/
│   └── README.md
│
├── license.txt
└── README.md                 # This file
```  

## Licensing

### Fonts
- **Poppins**, **Inter**, **Space Grotesk** are distributed under the **SIL Open Font License (OFL 1.1)**.
- Free for personal and commercial projects, redistribution, and embedding.
- Font ownership is **not** transferred; they remain under their original open-source licenses.

### Logos, icons, wordmarks, layouts, and custom graphics
- © Renewt3ch® (original creator).
- Upon purchase, the buyer receives an **exclusive, worldwide, royalty-free license** to use these brand assets in commercial projects, including resale of websites and digital products built with this branding.
- The original creator will **not** re-sell or re-license this exact brand package once ownership has been transferred.

*This is not legal advice; consult your legal advisor for jurisdiction-specific questions.*

---

## How to Use This Kit

1. Review the visual system in `/brand-guide/brand-guide.html`.
2. Choose your implementation path: web app, SaaS landing page, personal brand site, or resale bundle.
3. Pull colors & typography from `/assets/colors` and `/assets/fonts`.
4. Export logo variants from `/assets/logos` for favicons, social avatars, and hero sections.
5. Follow `/instructions/README.md` for uploading to your platform (Webflow, Vercel, custom code, etc.) and for transfer to a buyer. **Quick print:** open [`instructions/index.html`](./instructions/index.html) for one-click access to the printable guides.

---

## CSS Variables (Drop-in)

> Copy the CSS below into `brand-guide/assets/brand.css`, then include in `brand-guide/brand-guide.html`:
>
> ```html
> <link rel="stylesheet" href="assets/brand.css">
> ```
>
> Optional: Add `data-theme="light"` on `<html>` to preview the light tokens.

**Palette → Tokens**

| Token                 | Hex       | From palette   |
|----------------------|-----------|----------------|
| `--color-bg`         | `#0D0D0D` | Infinite Black |
| `--color-bg-elevated`| `#151515` | Carbon Gray    |
| `--color-fg`         | `#FFFFFF` | Pure White     |
| `--color-accent`     | `#00FFA3` | Signal Green   |
| `--color-accent-2`   | `#03FF7D` | Neon Green     |

```css
/* File: brand-guide/assets/brand.css */
/* Why: self-hosted variable fonts (OFL 1.1) + palette tokens consistent with README. */

@font-face {
  font-family: "Inter";
  src: url("../../assets/fonts/inter/Inter-Variable.woff2") format("woff2-variations");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "Poppins";
  src: url("../../assets/fonts/poppins/Poppins-Variable.woff2") format("woff2-variations");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "Space Grotesk";
  src: url("../../assets/fonts/space-grotesk/SpaceGrotesk-Variable.woff2") format("woff2-variations");
  font-weight: 300 700;
  font-style: normal;
  font-display: swap;
}

/* ---------- Tokens (Dark default) ---------- */
:root {
  /* Families */
  --font-display: "Poppins", "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, ui-sans-serif, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
  --font-sans-ui: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, ui-sans-serif, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
  --font-alt: "Space Grotesk", "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, ui-sans-serif, sans-serif;

  /* Weights */
  --weight-regular: 400;
  --weight-medium: 500;
  --weight-semibold: 600;
  --weight-bold: 700;

  /* Type scale (from README) */
  --size-hero: clamp(3rem, 6vw + 1rem, 4.5rem);         /* 48–72px */
  --size-section: clamp(2rem, 3vw + 0.5rem, 3rem);      /* 32–48px */
  --size-sub: clamp(1.375rem, 1.25vw + 1rem, 1.75rem);  /* 22–28px */
  --size-ui: clamp(0.875rem, 0.5vw + 0.5rem, 1.125rem); /* 14–18px */
  --size-body: clamp(1rem, 0.25vw + 0.875rem, 1.125rem);/* 16–18px */
  --size-caption: clamp(0.75rem, 0.25vw + 0.625rem, 0.875rem);/*12–14px*/

  /* Core palette tokens (Renewt3ch Color System) */
  --color-bg: #0D0D0D;             /* Infinite Black */
  --color-bg-elevated: #151515;    /* Carbon Gray */
  --color-fg: #FFFFFF;             /* Pure White */
  --color-accent: #00FFA3;         /* Signal Green */
  --color-accent-2: #03FF7D;       /* Neon Green */

  /* Derived */
  --color-fg-muted: color-mix(in oklab, var(--color-fg), var(--color-bg) 60%);
  --color-border: #1A1A1A; /* stays within 0D–15 range per rules */
  --color-accent-contrast: #0D0D0D; /* dark text on bright green for WCAG AA */

  /* Surfaces */
  --radius: 12px;
  --shadow-1: 0 1px 2px rgba(0,0,0,.12), 0 6px 16px rgba(0,0,0,.18);
}

/* Light theme override (optional) */
:root[data-theme="light"] {
  --color-bg: #FFFFFF;
  --color-bg-elevated: #F6F7F9;
  --color-fg: #0D0D0D;
  --color-fg-muted: #4B5563;
  --color-border: #E5E7EB;
}

/* ---------- Base ---------- */
html, body { background: var(--color-bg); color: var(--color-fg); }
body {
  font-family: var(--font-sans-ui);
  font-weight: var(--weight-regular);
  font-size: var(--size-body);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
img { max-width: 100%; height: auto; display: block; }

/* ---------- Type mappings ---------- */
.hero, h1.hero {
  font-family: var(--font-display);
  font-weight: var(--weight-bold);
  font-size: var(--size-hero);
  line-height: 1.1;
}
.section-title, h2.section-title {
  font-family: var(--font-display);
  font-weight: var(--weight-semibold);
  font-size: var(--size-section);
  line-height: 1.2;
}
.subheading, h3.subheading {
  font-family: var(--font-alt);
  font-weight: var(--weight-medium);
  font-size: var(--size-sub);
  line-height: 1.2;
}
.label, .btn, button, [role="button"] {
  font-family: var(--font-sans-ui);
  font-weight: var(--weight-medium);
  font-size: var(--size-ui);
}
.caption, small {
  font-family: var(--font-sans-ui);
  font-weight: var(--weight-regular);
  font-size: var(--size-caption);
  color: var(--color-fg-muted);
}

/* ---------- Components ---------- */
.card {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  box-shadow: var(--shadow-1);
}
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
  padding: .625rem 1rem;
  border-radius: calc(var(--radius) - 4px);
  color: var(--color-accent-contrast);
  background: var(--color-accent);
  border: 1px solid color-mix(in oklab, var(--color-accent), black 18%);
  text-decoration: none;
  transition: all .15s ease;
}
.btn:is(:hover, :focus-visible) {
  filter: saturate(1.05) brightness(1.03);
  transform: translateY(-1px);
}
.btn--alt {
  background: var(--color-accent-2);
  border-color: color-mix(in oklab, var(--color-accent-2), black 18%);
}
```