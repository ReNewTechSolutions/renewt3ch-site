// Renewt3ch · tiny enhancements

// Glass nav on scroll
const header = document.querySelector('.site-header');
const onScroll = () => {
  if (!header) return;
  if (window.scrollY > 8) header.classList.add('scrolled');
  else header.classList.remove('scrolled');
};
onScroll(); // initial
window.addEventListener('scroll', onScroll, { passive: true });

// Mobile menu
const hamb = document.querySelector('.hamb');
const navLinks = document.querySelector('.nav-links');
if (hamb && navLinks) {
  hamb.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });
  navLinks.addEventListener('click', (e) => {
    if (e.target.tagName === 'A') navLinks.classList.remove('open');
  });
}